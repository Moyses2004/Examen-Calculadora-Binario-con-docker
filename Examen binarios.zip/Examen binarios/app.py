from flask import Flask, request, render_template_string

app = Flask(__name__)

# diseño
HTML_PAGINA = """
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Calculadora de Binarios</title>
    <style>
        * {
            box-sizing: border-box;
        }

        body {
            margin: 0;
            padding: 0;
            font-family: Arial, sans-serif;
            background: #f3f4f6;
            display: flex;
            justify-content: center;
            align-items: center;
            min-height: 100vh;
        }

        .card {
            background: #ffffff;
            width: 420px;
            padding: 25px 30px 30px 30px;
            border-radius: 16px;
            box-shadow: 0 10px 25px rgba(0, 0, 0, 0.10);
        }

        h1 {
            margin: 0 0 8px 0;
            font-size: 24px;
            color: #111827;
        }

        .subtitulo {
            margin: 0 0 20px 0;
            font-size: 14px;
            color: #6b7280;
        }

        label {
            display: block;
            margin-top: 12px;
            margin-bottom: 4px;
            font-size: 14px;
            color: #374151;
            font-weight: 600;
        }

        input[type="text"] {
            width: 100%;
            padding: 8px 10px;
            border-radius: 8px;
            border: 1px solid #d1d5db;
            font-size: 14px;
            outline: none;
        }

        input[type="text"]:focus {
            border-color: #3b82f6;
            box-shadow: 0 0 0 1px rgba(59, 130, 246, 0.3);
        }

        .fila-botones {
            margin-top: 18px;
            display: flex;
            justify-content: flex-end;
        }

        button {
            padding: 8px 18px;
            border-radius: 999px;
            border: none;
            font-size: 14px;
            font-weight: 600;
            cursor: pointer;
            background: #3b82f6;
            color: white;
            transition: background 0.2s ease, transform 0.1s ease;
        }

        button:hover {
            background: #2563eb;
        }

        button:active {
            transform: scale(0.97);
        }

        .error {
            margin-top: 12px;
            padding: 8px 10px;
            border-radius: 8px;
            background: #fef2f2;
            color: #b91c1c;
            font-size: 13px;
        }

        .resultado {
            margin-top: 18px;
            padding: 12px 14px;
            border-radius: 10px;
            background: #eff6ff;
            border: 1px solid #bfdbfe;
            font-size: 14px;
            color: #1f2937;
        }

        .resultado-titulo {
            font-weight: 700;
            margin-bottom: 6px;
            color: #1d4ed8;
        }

        .resultado-item {
            margin: 3px 0;
        }

        .resultado-item span {
            font-weight: 600;
        }

        .nota-ejemplo {
            margin-top: 10px;
            font-size: 12px;
            color: #9ca3af;
        }
    </style>
</head>
<body>
    <div class="card">
        <h1>Calculadora de números binarios</h1>
        <p class="subtitulo">
            Ingresa dos números binarios (0 y 1) para obtener la suma y la multiplicación.
        </p>

        <form method="post">
            <label for="bin_a">Binario A</label>
            <input type="text" id="bin_a" name="bin_a" value="{{ a }}" placeholder="Ejemplo: 1010" required>

            <label for="bin_b">Binario B</label>
            <input type="text" id="bin_b" name="bin_b" value="{{ b }}" placeholder="Ejemplo: 1101" required>

            <div class="fila-botones">
                <button type="submit">Calcular</button>
            </div>
        </form>

        {% if error %}
            <div class="error">{{ error }}</div>
        {% endif %}

        {% if resultado_suma or resultado_mult %}
            <div class="resultado">
                <div class="resultado-titulo">Resultados</div>
                <p class="resultado-item">
                    <span>Suma binaria:</span> {{ resultado_suma }}
                </p>
                <p class="resultado-item">
                    <span>Multiplicación binaria:</span> {{ resultado_mult }}
                </p>
            </div>
        {% endif %}

        <p class="nota-ejemplo">
            Ejemplo del examen: A = 1010, B = 1101 → Suma = 10111, Multiplicación = 1001110.
        </p>
    </div>
</body>
</html>
"""

def es_binario(cadena: str) -> bool:
    """Verifica que la cadena solo tenga 0 y 1 y no esté vacía."""
    return cadena != "" and all(c in "01" for c in cadena)


@app.route("/", methods=["GET", "POST"])
def index():
    a = ""
    b = ""
    resultado_suma = ""
    resultado_mult = ""
    error = ""

    if request.method == "POST":
        a = request.form.get("bin_a", "").strip()
        b = request.form.get("bin_b", "").strip()

        if not (es_binario(a) and es_binario(b)):
            error = "Solo se permiten números binarios (0 y 1)."
        else:
            a_dec = int(a, 2)
            b_dec = int(b, 2)

            suma_dec = a_dec + b_dec
            mult_dec = a_dec * b_dec

            resultado_suma = bin(suma_dec)[2:]
            resultado_mult = bin(mult_dec)[2:]

    return render_template_string(
        HTML_PAGINA,
        a=a,
        b=b,
        resultado_suma=resultado_suma,
        resultado_mult=resultado_mult,
        error=error
    )


if __name__ == "__main__":
    app.run(host="0.0.0.0", port=5000, debug=True)
